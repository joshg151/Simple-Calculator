﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCalc
{
    internal class Program
    {
        //Does simple addition
        public static double Addition(double num1, double num2)
        {
            return num1 + num2; ;
        }
        //Does simple subtraction
        public static double Subtraction(double num1, double num2)
        {
            return num1 - num2;
        }
        //Does multiplication
        public static double Multi(double num1, double num2)
        {
            return num1 * num2;
        }
        //does division
        public static double Divis(double num1, double num2)
        {
            return num1 / num2;
        }
        //asks the question of which pemdas they want to use
        public static double Question()
        {
            Console.WriteLine("Enter 1 for add, 2 for subtract, 3 for multiply, 4 for division");
            double choose = Convert.ToDouble(Console.ReadLine());
            return choose;
        }
        public static void PerformOperations(double response, double num1, double num2)
        {
            if (response == 1)
            {
                response = Program.Addition(num1, num2);
                Console.WriteLine("The results of your addition are " + response);
                Console.ReadKey();
            }
            else if (response == 2)
            {
                response = Program.Subtraction(num1, num2);
                Console.WriteLine("The results of your subtraction are " + response);
                Console.ReadKey();
            }
            else if (response == 3)
            {
                response = Program.Multi(num1, num2);
                Console.WriteLine("The results of your multiplication are " + response);
                Console.ReadKey();
            }
            else if (response == 4)
            {
                if (num2 != 0)
                {
                    response = Program.Divis(num1, num2);
                    Console.WriteLine("The results of your division are " + response);
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("You are unable to divide by 0");
                    Console.ReadKey();
                }
            }
            else
            {
                Console.WriteLine("You have entered a invalid number/choice Please try again with a number between 1 and 4");
                Console.ReadKey();
            }
        }

        //asks for the 2 nums to be entered
        public static (double, double) GetTwoNumbersFromUser()
        {
            double num1, num2;

            // Prompt the user for input
            Console.WriteLine("Please enter two numbers separated by a space:");

            // Read the input from the user
            string input = Console.ReadLine();

            // Split the input string into parts based on spaces
            string[] parts = input.Split(' ');

            // Check if there are exactly two parts
            if (parts.Length == 2)
            {
                try
                {
                    // Convert the parts to double
                    num1 = Convert.ToDouble(parts[0]);
                    num2 = Convert.ToDouble(parts[1]);

                    return (num1, num2);
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input. Please enter valid numbers.");
                    return (0, 0); // Return default values if conversion fails
                }
            }
            else
            {
                Console.WriteLine("Please enter exactly two numbers.");
                return (0, 0); // Return default values if input is incorrect
            }
        }
    }
}
