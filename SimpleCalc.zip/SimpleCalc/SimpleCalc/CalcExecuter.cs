﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCalc
{
    internal class CalcExecuter
    {
        static void Main(string[] args)
        {
            double response;
            Console.WriteLine("Do you want to use the Calculator? If yes, type Yes, if not type anything else");
            string UseCalculator = Console.ReadLine();
            while (UseCalculator == "yes")
            {
                //Console.WriteLine("Do you want to use the Calculator? If yes, type Yes, if not type anything else");
                //UseCalculator = Console.ReadLine();
                var (num1, num2) = Program.GetTwoNumbersFromUser();
                response = Program.Question();
                Program.PerformOperations(response, num1, num2);
                Console.WriteLine("Do you want to use the Calculator? If yes, type Yes, if not type anything else");
                UseCalculator = Console.ReadLine();
            }
        }

    }

}

    