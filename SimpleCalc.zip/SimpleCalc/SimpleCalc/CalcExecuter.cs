﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleCalc
{
    internal class CalcExecuter
    {
        static void Main(string[] args)
        {
            double response;

            var (num1, num2) = Program.GetTwoNumbersFromUser();
            response = Program.Question();
            Program.PerformOperations(response, num1, num2);
        }

    }

}

    